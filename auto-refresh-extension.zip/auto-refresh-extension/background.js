// 메시지 수신 (popup → background)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'start') {
    startRefresh(msg.tabId, msg.intervalSec, msg.startedAt);
  } else if (msg.action === 'stop') {
    stopRefresh(msg.tabId);
  }
});

// 알람 발생 시 해당 탭 새로고침
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith('refresh_')) return;

  const tabId = parseInt(alarm.name.replace('refresh_', ''));
  const stored = await chrome.storage.local.get(`tab_${tabId}`);
  if (!stored[`tab_${tabId}`]) return;

  try {
    await chrome.tabs.reload(tabId);
  } catch (e) {
    // 탭이 닫힌 경우 자동 정리
    stopRefresh(tabId);
  }
});

// 탭이 닫히면 자동 정지
chrome.tabs.onRemoved.addListener((tabId) => {
  stopRefresh(tabId);
});

// ── 내부 함수 ──────────────────────────────────────────

async function startRefresh(tabId, intervalSec, startedAt) {
  const alarmName = `refresh_${tabId}`;

  // 기존 알람 제거 후 재생성
  await chrome.alarms.clear(alarmName);
  chrome.alarms.create(alarmName, {
    delayInMinutes: intervalSec / 60,
    periodInMinutes: intervalSec / 60
  });

  // 상태 저장
  await chrome.storage.local.set({
    [`tab_${tabId}`]: { intervalSec, startedAt }
  });

  // 아이콘에 배지 표시
  chrome.action.setBadgeText({ text: 'ON', tabId });
  chrome.action.setBadgeBackgroundColor({ color: '#22c55e', tabId });
}

async function stopRefresh(tabId) {
  const alarmName = `refresh_${tabId}`;
  await chrome.alarms.clear(alarmName);
  await chrome.storage.local.remove(`tab_${tabId}`);

  try {
    chrome.action.setBadgeText({ text: '', tabId });
  } catch (e) {}
}
